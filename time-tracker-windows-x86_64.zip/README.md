# Time Tracker

A small desktop time tracker built with Rust, egui/eframe, and SQLite.

## Run

```sh
cargo run
```

## CI builds

GitHub Actions builds Arch Linux and Windows x86_64 release artifacts on pushes
to `main`, pull requests, and manual workflow runs.

Download the `time-tracker-arch-x86_64` artifact, extract it, then run:

```sh
./scripts/install-desktop.sh
```

Download the `time-tracker-windows-x86_64` artifact, extract it, then run:

```powershell
.\time-tracker.exe
```

The app stores its SQLite database at:

- `$XDG_DATA_HOME/time-tracker/tracker.sqlite3`
- `~/.local/share/time-tracker/tracker.sqlite3` when `XDG_DATA_HOME` is not set
- `%LOCALAPPDATA%\time-tracker\tracker.sqlite3` on Windows

## MCP server

`time-tracker-mcp` is a stdio [Model Context Protocol](https://modelcontextprotocol.io)
server that lets AI assistants list, create, start, pause, finish, archive, and
move tasks. It forwards every call to the running app through the same local
automation bridge as `time-trackerctl`, so Time Tracker must be open.

Register it with Claude Code after running `./scripts/install-desktop.sh`:

```sh
claude mcp add --scope user time-tracker -- ~/.local/bin/time-tracker-mcp
```
