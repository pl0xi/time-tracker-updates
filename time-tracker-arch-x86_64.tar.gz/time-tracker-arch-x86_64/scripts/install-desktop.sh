#!/usr/bin/env bash
set -euo pipefail

project_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
binary="$project_dir/target/release/time-tracker"
ctl_binary="$project_dir/target/release/time-trackerctl"

if [[ ! -x "$binary" ]]; then
  echo "Release binary not found at $binary" >&2
  echo "Run: cargo +nightly build --release" >&2
  exit 1
fi

if [[ ! -x "$ctl_binary" ]]; then
  echo "Control binary not found at $ctl_binary" >&2
  echo "Run: cargo +nightly build --release" >&2
  exit 1
fi

install -d "$HOME/.local/bin"
tmp_binary="$HOME/.local/bin/.time-tracker.$$"
install -m755 "$binary" "$tmp_binary"
mv -f "$tmp_binary" "$HOME/.local/bin/time-tracker"
tmp_ctl_binary="$HOME/.local/bin/.time-trackerctl.$$"
install -m755 "$ctl_binary" "$tmp_ctl_binary"
mv -f "$tmp_ctl_binary" "$HOME/.local/bin/time-trackerctl"
install -Dm644 "$project_dir/assets/dev.benjamin.TimeTracker.svg" \
  "$HOME/.local/share/icons/hicolor/scalable/apps/dev.benjamin.TimeTracker.svg"
install -Dm644 "$project_dir/assets/dev.benjamin.TimeTracker.png" \
  "$HOME/.local/share/icons/hicolor/256x256/apps/dev.benjamin.TimeTracker.png"
install -Dm644 "$project_dir/packaging/dev.benjamin.TimeTracker.desktop" \
  "$HOME/.local/share/applications/dev.benjamin.TimeTracker.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$HOME/.local/share/applications" >/dev/null 2>&1 || true
fi

if command -v gtk-update-icon-cache >/dev/null 2>&1; then
  gtk-update-icon-cache -q "$HOME/.local/share/icons/hicolor" >/dev/null 2>&1 || true
fi

echo "Installed Time Tracker desktop launcher."
