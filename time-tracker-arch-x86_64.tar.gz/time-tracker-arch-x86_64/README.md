# Time Tracker

A small desktop time tracker built with Rust, GTK 4, libadwaita, and SQLite.

## Run

```sh
cargo +nightly run
```

## CI builds

GitHub Actions builds Arch Linux and Windows x86_64 release artifacts on pushes
to `main`, pull requests, and manual workflow runs.

Download the `time-tracker-arch-x86_64` artifact, extract it, then run:

```sh
./scripts/install-desktop.sh
```

Download the `time-tracker-windows-x86_64` artifact, extract it, then run:

```powershell
.\time-tracker.exe
```

The app stores its SQLite database at:

- `$XDG_DATA_HOME/time-tracker/tracker.sqlite3`
- `~/.local/share/time-tracker/tracker.sqlite3` when `XDG_DATA_HOME` is not set
- `%LOCALAPPDATA%\time-tracker\tracker.sqlite3` on Windows
